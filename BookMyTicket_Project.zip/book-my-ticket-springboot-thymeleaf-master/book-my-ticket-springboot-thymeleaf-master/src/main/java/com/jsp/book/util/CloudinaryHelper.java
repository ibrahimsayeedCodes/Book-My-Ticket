package com.jsp.book.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;

@Component
public class CloudinaryHelper {

	private static final String MOVIE_FOLDER = "BMT-Movies";
	private static final String THEATER_FOLDER = "BMT-Theater";
	private static final String QR_FOLDER = "BMT-Theater-QR";

	private static final String FALLBACK_IMAGE = "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1000&auto=format&fit=crop";

	private final String cloudinaryUrl;
	private final Cloudinary cloudinary;
	private final boolean useCloudinary;

	public CloudinaryHelper(@Value("${cloudinary.url}") String cloudinaryUrl) {
		this.cloudinaryUrl = cloudinaryUrl;
		this.cloudinary = new Cloudinary(cloudinaryUrl);
		this.useCloudinary = cloudinaryUrl != null && !cloudinaryUrl.contains("123456789012345") && !cloudinaryUrl.isEmpty();
	}

	public String generateImageLink(MultipartFile file) {
		return upload(file, MOVIE_FOLDER);
	}

	public String getTheaterImageLink(MultipartFile file) {
		return upload(file, THEATER_FOLDER);
	}

	public String saveTicketQr(byte[] qr) {
		return upload(qr, QR_FOLDER);
	}

	/* ---------- Private helpers ---------- */

	private String upload(MultipartFile file, String folder) {
		if (file == null || file.isEmpty()) {
			return FALLBACK_IMAGE;
		}
		try {
			if (useCloudinary) {
				return uploadToCloudinary(file.getBytes(), folder);
			} else {
				return saveLocally(file.getBytes(), folder, file.getOriginalFilename());
			}
		} catch (IOException e) {
			return FALLBACK_IMAGE;
		}
	}

	private String upload(byte[] data, String folder) {
		if (useCloudinary) {
			return uploadToCloudinary(data, folder);
		} else {
			return saveLocally(data, folder, "qr-code.png");
		}
	}

	@SuppressWarnings("unchecked")
	private String uploadToCloudinary(byte[] data, String folder) {
		try {
			Map<String, Object> params = ObjectUtils.asMap("folder", folder, "use_filename", true);
			return (String) cloudinary.uploader().upload(data, params).get("secure_url");
		} catch (Exception e) {
			System.err.println("Cloudinary upload failed: " + e.getMessage());
			return FALLBACK_IMAGE;
		}
	}

	private String saveLocally(byte[] data, String folder, String originalFilename) {
		try {
			// Normalize folder for URL and Path
			String subFolder = folder.toLowerCase().contains("movie") ? "movies" : folder.toLowerCase();
			String uploadDir = "uploads/" + subFolder;
			
			Path path = Paths.get(uploadDir);
			if (!Files.exists(path)) {
				Files.createDirectories(path);
			}

			String fileName = UUID.randomUUID().toString() + "_" + originalFilename;
			Path filePath = path.resolve(fileName);
			
			Files.write(filePath, data);

			// Return the relative URL
			return "/uploads/" + subFolder + "/" + fileName;
		} catch (IOException e) {
			System.err.println("Local upload failed: " + e.getMessage());
			return FALLBACK_IMAGE;
		}
	}
}
