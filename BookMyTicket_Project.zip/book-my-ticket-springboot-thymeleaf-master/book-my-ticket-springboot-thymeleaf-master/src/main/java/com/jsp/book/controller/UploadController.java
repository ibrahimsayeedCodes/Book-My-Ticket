package com.jsp.book.controller;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
public class UploadController {

    @GetMapping("/uploads/{folder}/{filename:.+}")
    public ResponseEntity<Resource> serveUploads(@PathVariable String folder, @PathVariable String filename) {
        try {
            Path file = Paths.get("uploads").resolve(folder).resolve(filename);
            
            if (!Files.exists(file)) {
                // Check if we are running from the parent directory
                Path alternative = Paths.get("book-my-ticket-springboot-thymeleaf-master", "uploads").resolve(folder).resolve(filename);
                if (Files.exists(alternative)) {
                    file = alternative;
                }
            }

            Resource resource = new UrlResource(file.toUri());

            if (resource.exists() || resource.isReadable()) {
                MediaType mediaType = MediaType.IMAGE_JPEG;
                if (filename.toLowerCase().endsWith(".png")) {
                    mediaType = MediaType.IMAGE_PNG;
                } else if (filename.toLowerCase().endsWith(".gif")) {
                    mediaType = MediaType.IMAGE_GIF;
                }
                
                return ResponseEntity.ok()
                        .contentType(mediaType)
                        .body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().body(new org.springframework.core.io.ByteArrayResource(e.toString().getBytes()));
        }
    }
}
